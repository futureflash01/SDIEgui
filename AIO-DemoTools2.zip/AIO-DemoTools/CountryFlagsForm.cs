﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.NetworkInformation;
using static System.Net.WebRequestMethods;
using System.Diagnostics;
using System.Threading;
using File = System.IO.File;

namespace AIO_DemoTools
{
    
    public partial class CountryFlagsForm : Form
    {
        
        public CountryFlagsForm()
        {
            InitializeComponent();
        }

        private void CountryFlagsForm_Load(object sender, EventArgs e)
        {
            flagPictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            countriesComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            saveImageButton.Enabled = false;
            this.Size = new Size(163, 307);
            this.CenterToScreen();
        }
        
        private void selectFlagButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (countriesComboBox.Text.Length == 0)
                {
                    MessageBox.Show(
                    "Please choose a country before loading",
                    "Empty Selection",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                }
                else
                {
                    flagPictureBox.Load("https://flagcdn.com/w1280/" + countriesComboBox.Text + ".png");
                    saveImageButton.Enabled = true;
                    this.Size = new Size(587, 307);
                    this.CenterToScreen();
                }
            }
            catch (WebException)
            {
                MessageBox.Show(
                $"Coud not find the country: '{countriesComboBox.Text}'",
                "Invalid Selection",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
        }

        private void countryCodesHelpLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("https://pastebin.com/raw/jfF0eUYs");
        }

        private void saveImageButton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog() { Filter = @"PNG|*.png" })
            {
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    flagPictureBox.Image.Save(saveFileDialog.FileName);
                    Thread.Sleep(1000);
                    if (File.Exists(saveFileDialog.FileName))
                    {
                        DialogResult dialogResult = MessageBox.Show(
                        $"Image successfully saved to {saveFileDialog.FileName}. Would you like to view it now?",
                        "Image Saved!",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                        if (dialogResult == DialogResult.Yes)
                        {
                            Process.Start(saveFileDialog.FileName);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Image could not be saved. Please try again!", "Image Not Saved!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
