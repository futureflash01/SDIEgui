﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class AIOToolsForm : Form
    {
        public AIOToolsForm()
        {
            InitializeComponent(); 
        }

        public static bool IsConnectedToInternet()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
            catch (WebException)
            {
                return false;
            }
        }

        private void convertTempButton_Click(object sender, EventArgs e)
        {
            var ConvTempForm = new ConvertTempForm();
            ConvTempForm.ShowDialog();
        }

        private void countryFlagsButton_Click(object sender, EventArgs e)
        {
            var CountryFlagsForm = new CountryFlagsForm();

            if (IsConnectedToInternet())
            {
                CountryFlagsForm.ShowDialog();
            }
            else if (!IsConnectedToInternet())
            {
                MessageBox.Show(
                "It appears you're not connected to the internet. Please do so before opening this app",
                "No internet connection!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
            "All in One Tools is a program that has very simple and easy tools to use. It is mainly a program that I made to help build my passion again for programming :(\r\n\r\n------------------------------------------------------------------------------\r\n\r\n\r\nCreated by FutureFlash on 6/28/2023",
            "All in One Tools (v1.0)",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
        }

        private void generateQRButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
            "This feature is still in development!",
            "Not Ready Yet",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information
            );
        }
    }
}
