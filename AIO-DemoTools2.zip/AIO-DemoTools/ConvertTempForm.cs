﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class ConvertTempForm : Form
    {
        public bool CtoF;
        public bool FtoC;

        public ConvertTempForm()
        {
            InitializeComponent();
        }

        private void ConvertTempForm_Load(object sender, EventArgs e)
        {
            CTextbox.Enabled = false;
            FtoC = true;
        }

        private void switchButton_Click(object sender, EventArgs e)
        {
            if (!CTextbox.Enabled)
            {
                FtoC = false;
                CtoF = true;
                CTextbox.Enabled = true;
                FTextbox.Enabled = false;
            }
            else if (CTextbox.Enabled)
            {
                CtoF = false;
                FtoC = true;
                CTextbox.Enabled = false;
                FTextbox.Enabled = true;
            }
        }

        private void FTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '-') && (e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('-') > -1) && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void CTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '-') && (e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('-') > -1) && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void clearLabel_Click(object sender, EventArgs e)
        {
            FTextbox.Clear();
            CTextbox.Clear();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            if (CtoF)
            {
                try
                {
                    double cInt = Double.Parse(CTextbox.Text);
                    FTextbox.Text = Convert.ToString((cInt * 1.8) + 32);
                }
                catch (FormatException)
                {
                    MessageBox.Show(
                    "Please input a real number and try again",
                    "Invalid Input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                }
            }

            else if (FtoC)
            {
                try
                {
                    double fInt = Double.Parse(FTextbox.Text);
                    CTextbox.Text = Convert.ToString((fInt - 32) * 5/9);
                }
                catch (FormatException)
                {
                    MessageBox.Show(
                    "Please input a real number and try again",
                    "Invalid Input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                }
            }
        }
    }
}
