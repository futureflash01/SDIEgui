﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class AIOToolsForm : Form
    {
        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int Description, int ReservedValue);

        public Form ConvertTemperatureForm = new ConvertTempForm();
        public Form CountryFlagsForm = new CountryFlagsForm();
        public Form QRCodeGenForm = new QRCodeGenForm();

        public AIOToolsForm()
        {
            InitializeComponent(); 
        }

        private void convertTempButton_Click(object sender, EventArgs e)
        {
            ConvertTemperatureForm.ShowDialog();
        }

        private void countryFlagsButton_Click(object sender, EventArgs e)
        {
            int Desc;

            if (InternetGetConnectedState(out Desc, 0).ToString() == "True")
            {
                CountryFlagsForm.ShowDialog();
            }

            else if (InternetGetConnectedState(out Desc, 0).ToString() == "False")
            {
                MessageBox.Show(
                "It appears you're not connected to the internet. Please do so before opening this app",
                "No internet connection!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
            "All in One Tools is a program that has very simple and easy tools to use. It is mainly a program that I made to help build my passion again for programming :(\r\n\r\n------------------------------------------------------------------------------\r\n\r\n\r\nCreated by FutureFlash on 6/28/2023",
            "All in One Tools (v1.0)",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
        }

        private void generateQRButton_Click(object sender, EventArgs e)
        {
            QRCodeGenForm.ShowDialog();
        }
    }
}
