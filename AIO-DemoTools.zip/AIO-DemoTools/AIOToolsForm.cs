﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class AIOToolsForm : Form
    {
        public AIOToolsForm()
        {
            InitializeComponent(); 
        }

        private void convertTempButton_Click(object sender, EventArgs e)
        {
            var ConvTempForm = new ConvertTempForm();
            ConvTempForm.ShowDialog();
        }

        private void countryFlagsButton_Click(object sender, EventArgs e)
        {
            var CountryFlagsForm = new CountryFlagsForm();
            CountryFlagsForm.ShowDialog();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
            "All in One Tools is a program that has very simple and easy tools to use. It is mainly a program that I made to help build my passion again for programming :(\r\n\r\n------------------------------------------------------------------------------\r\n\r\n\r\nCreated by FutureFlash on 6/28/2023",
            "All in One Tools (v1.0)",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
        }
    }
}
