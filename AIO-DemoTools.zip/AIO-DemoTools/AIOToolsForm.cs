﻿using System;
using System.Windows.Forms;
using System.Net.NetworkInformation;

namespace AIO_DemoTools
{
    public partial class AIOToolsForm : Form
    {
        private Form ConvertTemperatureForm = new ConvertTempForm();
        private Form CountryFlagsForm = new CountryFlagsForm();
        private Form QRCodeGenForm = new QRCodeGenForm();
        private Form DiceRollForm = new DiceRollForm();
        private Form DigitalClockForm = new DigitalClockForm();

        public AIOToolsForm()
        {
            InitializeComponent();
        }

        private void convertTempButton_Click(object sender, EventArgs e)
        {
            ConvertTemperatureForm.ShowDialog();
        }

        private void countryFlagsButton_Click(object sender, EventArgs e)
        {
            if (IsInternetConnected())
            {
                CountryFlagsForm.ShowDialog();
            }

            else
            {
                MessageBox.Show(
                "It appears you're not connected to the internet. Please do so before opening this app",
                "No internet connection!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
        }

        private bool IsInternetConnected()
        {
            return NetworkInterface.GetIsNetworkAvailable();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "All in One Tools is a program that has very simple and easy tools to use. It is mainly a program that I made to help build my passion again for programming :(\r\n\r\n------------------------------------------------------------------------------\r\n\r\n\r\nCreated by FutureFlash on 6/28/2023",
                "All in One Tools (v1.0)",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void generateQRButton_Click(object sender, EventArgs e)
        {
            QRCodeGenForm.ShowDialog();
        }

        private void diceRollButton_Click(object sender, EventArgs e)
        {
            DiceRollForm.ShowDialog();
        }

        private void digitalClockButton_Click(object sender, EventArgs e)
        {
            DigitalClockForm.ShowDialog();
        }
    }
}