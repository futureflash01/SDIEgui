﻿using System;
using System.Windows.Forms;
using System.Net.NetworkInformation;

namespace AIO_DemoTools
{
    public partial class AIOToolsForm : Form
    {
        private Form ConvertTemperatureForm = new ConvertTempForm();
        private Form CountryFlagsForm = new CountryFlagsForm();
        private Form QRCodeGenForm = new QRCodeGenForm();
        private Form DiceRollForm = new DiceRollForm();
        private Form DigitalClockForm = new DigitalClockForm();
        private Form SpeedTestForm = new SpeedTestForm();

        public AIOToolsForm()
        {
            InitializeComponent();
        }

        private bool IsInternetConnected()
        {
            return NetworkInterface.GetIsNetworkAvailable();
        }

        private void convertTempButton_Click(object sender, EventArgs e)
        {
            if (ConvertTemperatureForm.IsDisposed)
            {
                ConvertTemperatureForm = new ConvertTempForm();
                ConvertTemperatureForm.Show();
            }

            else
            {
                ConvertTemperatureForm.Show();
            }
        }

        private void countryFlagsButton_Click(object sender, EventArgs e)
        {
            if (IsInternetConnected())
            {
                if (CountryFlagsForm.IsDisposed)
                {
                    CountryFlagsForm = new CountryFlagsForm();
                    CountryFlagsForm.Show();
                }

                else
                {
                    CountryFlagsForm.Show();
                }
            }

            else
            {
                MessageBox.Show(
                "It appears you're not connected to the internet. Please do so before opening this app",
                "No internet connection!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "All in One Tools is a program that has very simple and easy tools to use. It is mainly a program that I made to help build my passion again for programming :(\r\n\r\n------------------------------------------------------------------------------\r\n\r\n\r\nCreated by FutureFlash on 6/28/2023",
                "All in One Tools (v1.0)",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void generateQRButton_Click(object sender, EventArgs e)
        {
            if (QRCodeGenForm.IsDisposed)
            {
                QRCodeGenForm = new QRCodeGenForm();
                QRCodeGenForm.Show();
            }

            else
            {
                QRCodeGenForm.Show();
            }
        }

        private void diceRollButton_Click(object sender, EventArgs e)
        {
            if (DiceRollForm.IsDisposed)
            {
                DiceRollForm = new DiceRollForm();
                DiceRollForm.Show();
            }

            else
            {
                DiceRollForm.Show();
            }
        }

        private void digitalClockButton_Click(object sender, EventArgs e)
        {
            if (DigitalClockForm.IsDisposed)
            {
                DigitalClockForm = new DigitalClockForm();
                DigitalClockForm.Show();
            }

            else
            {
                DigitalClockForm.Show();
            }
        }

        private void speedTestButton_Click(object sender, EventArgs e)
        {
            if (SpeedTestForm.IsDisposed)
            {
                SpeedTestForm = new SpeedTestForm();
                SpeedTestForm.Show();
            }

            else
            {
                SpeedTestForm.Show();
            }
        }
    }
}