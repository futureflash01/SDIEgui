﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class DiceRollForm : Form
    {
        private static readonly Random random = new Random();

        public DiceRollForm()
        {
            InitializeComponent();
            rollDiceOutputVideo.PlayStateChange += rollDiceOutputVideo_PlayStateChange;
        }

        private void DiceRollForm_Load(object sender, EventArgs e)
        {
            ConfigureDiceOutputVideo();
            ConfigureFormSize();
        }

        private void ConfigureDiceOutputVideo()
        {
            rollDiceOutputVideo.uiMode = "none";
            rollDiceOutputVideo.Hide();
        }

        private void ConfigureFormSize()
        {
            this.Size = new Size(275, 353);
        }

        public static int GenerateRandomNumber(int min, int max)
        {
            lock (random)
            {
                return random.Next(min, max);
            }
        }

        public void wait(int milliseconds)
        {
            var timer1 = new System.Windows.Forms.Timer();
            if (milliseconds == 0 || milliseconds < 0) return;

            timer1.Interval = milliseconds;
            timer1.Enabled = true;
            timer1.Start();

            timer1.Tick += (s, e) =>
            {
                timer1.Enabled = false;
                timer1.Stop();
            };

            while (timer1.Enabled)
            {
                Application.DoEvents();
            }
        }

        private void rollDiceButton_Click(object sender, EventArgs e)
        {
            ConfigureFormSize();
            rollDiceOutputVideo.Show();

            var output = GenerateRandomNumber(1, 7);
            hiddenLabel.Text = output.ToString();

            rollDiceOutputVideo.URL = $"dice{hiddenLabel.Text}.avi";
            rollDiceOutputVideo.Ctlcontrols.play();
            wait(1700);
            rollDiceOutputVideo.Ctlcontrols.pause();

            rollDiceOutputLabel.Text = "Output: " + hiddenLabel.Text;
            rollDiceOutputLabel.Font = new Font("Arial Black", 12);

            rollDiceOutputVideo.Width = 225;
            rollDiceOutputVideo.Height = 225;
            rollDiceOutputVideo.stretchToFit = false;
            this.CenterToScreen();
        }

        private void rollDiceOutputVideo_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (e.newState == 1)
            {
                rollDiceOutputLabel.Text = "Output: " + hiddenLabel.Text;
                rollDiceOutputLabel.Location = new Point(61, 96);
                rollDiceOutputLabel.Font = new Font("Arial Black", 16);

                rollDiceOutputVideo.Width = 225;
                rollDiceOutputVideo.Height = 225;
                rollDiceOutputVideo.stretchToFit = false;
                rollDiceOutputVideo.fullScreen = false;
                this.Size = new Size(255, 225);
                this.CenterToScreen();
                rollDiceOutputVideo.Hide();
            }
        }

        private void DiceRollForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ConfigureDiceOutputVideo();
            ConfigureFormSize();
        }

        private void DiceRollForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            while (Controls.Count > 0)
            {
                Controls[0].Dispose();
            }
            InitializeComponent();
        }
    }
}
