﻿namespace AIO_DemoTools
{
    partial class CountryFlagsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CountryFlagsForm));
            this.countriesComboBox = new System.Windows.Forms.ComboBox();
            this.flagPictureBox = new System.Windows.Forms.PictureBox();
            this.flagPictureLabel = new System.Windows.Forms.Label();
            this.chooseCountryLabel = new System.Windows.Forms.Label();
            this.selectFlagButton = new System.Windows.Forms.Button();
            this.saveImageButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.flagPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // countriesComboBox
            // 
            this.countriesComboBox.FormattingEnabled = true;
            this.countriesComboBox.Items.AddRange(new object[] {
            "ad: Andorra",
            "ae: United Arab Emirates",
            "af: Afghanistan",
            "ag: Antigua and Barbuda",
            "ai: Anguilla",
            "al: Albania",
            "am: Armenia",
            "ao: Angola",
            "aq: Antarctica",
            "ar: Argentina",
            "as: American Samoa",
            "at: Austria",
            "au: Australia",
            "aw: Aruba",
            "ax: Åland Islands",
            "az: Azerbaijan",
            "ba: Bosnia and Herzegovina",
            "bb: Barbados",
            "bd: Bangladesh",
            "be: Belgium",
            "bf: Burkina Faso",
            "bg: Bulgaria",
            "bh: Bahrain",
            "bi: Burundi",
            "bj: Benin",
            "bl: Saint Barthélemy",
            "bm: Bermuda",
            "bn: Brunei",
            "bo: Bolivia",
            "bq: Caribbean Netherlands",
            "br: Brazil",
            "bs: Bahamas",
            "bt: Bhutan",
            "bv: Bouvet Island",
            "bw: Botswana",
            "by: Belarus",
            "bz: Belize",
            "ca: Canada",
            "cc: Cocos (Keeling) Islands",
            "cd: DR Congo",
            "cf: Central African Republic",
            "cg: Republic of the Congo",
            "ch: Switzerland",
            "ci: Côte d\'Ivoire (Ivory Coast)",
            "ck: Cook Islands",
            "cl: Chile",
            "cm: Cameroon",
            "cn: China",
            "co: Colombia",
            "cr: Costa Rica",
            "cu: Cuba",
            "cv: Cape Verde",
            "cw: Curaçao",
            "cx: Christmas Island",
            "cy: Cyprus",
            "cz: Czechia",
            "de: Germany",
            "dj: Djibouti",
            "dk: Denmark",
            "dm: Dominica",
            "do: Dominican Republic",
            "dz: Algeria",
            "ec: Ecuador",
            "ee: Estonia",
            "eg: Egypt",
            "eh: Western Sahara",
            "er: Eritrea",
            "es: Spain",
            "et: Ethiopia",
            "eu: European Union",
            "fi: Finland",
            "fj: Fiji",
            "fk: Falkland Islands",
            "fm: Micronesia",
            "fo: Faroe Islands",
            "fr: France",
            "ga: Gabon",
            "gb: United Kingdom",
            "gb-eng: England",
            "gb-nir: Northern Ireland",
            "gb-sct: Scotland",
            "gb-wls: Wales",
            "gd: Grenada",
            "ge: Georgia",
            "gf: French Guiana",
            "gg: Guernsey",
            "gh: Ghana",
            "gi: Gibraltar",
            "gl: Greenland",
            "gm: Gambia",
            "gn: Guinea",
            "gp: Guadeloupe",
            "gq: Equatorial Guinea",
            "gr: Greece",
            "gs: South Georgia",
            "gt: Guatemala",
            "gu: Guam",
            "gw: Guinea-Bissau",
            "gy: Guyana",
            "hk: Hong Kong",
            "hm: Heard Island and McDonald Islands",
            "hn: Honduras",
            "hr: Croatia",
            "ht: Haiti",
            "hu: Hungary",
            "id: Indonesia",
            "ie: Ireland",
            "il: Israel",
            "im: Isle of Man",
            "in: India",
            "io: British Indian Ocean Territory",
            "iq: Iraq",
            "ir: Iran",
            "is: Iceland",
            "it: Italy",
            "je: Jersey",
            "jm: Jamaica",
            "jo: Jordan",
            "jp: Japan",
            "ke: Kenya",
            "kg: Kyrgyzstan",
            "kh: Cambodia",
            "ki: Kiribati",
            "km: Comoros",
            "kn: Saint Kitts and Nevis",
            "kp: North Korea",
            "kr: South Korea",
            "kw: Kuwait",
            "ky: Cayman Islands",
            "kz: Kazakhstan",
            "la: Laos",
            "lb: Lebanon",
            "lc: Saint Lucia",
            "li: Liechtenstein",
            "lk: Sri Lanka",
            "lr: Liberia",
            "ls: Lesotho",
            "lt: Lithuania",
            "lu: Luxembourg",
            "lv: Latvia",
            "ly: Libya",
            "ma: Morocco",
            "mc: Monaco",
            "md: Moldova",
            "me: Montenegro",
            "mf: Saint Martin",
            "mg: Madagascar",
            "mh: Marshall Islands",
            "mk: North Macedonia",
            "ml: Mali",
            "mm: Myanmar",
            "mn: Mongolia",
            "mo: Macau",
            "mp: Northern Mariana Islands",
            "mq: Martinique",
            "mr: Mauritania",
            "ms: Montserrat",
            "mt: Malta",
            "mu: Mauritius",
            "mv: Maldives",
            "mw: Malawi",
            "mx: Mexico",
            "my: Malaysia",
            "mz: Mozambique",
            "na: Namibia",
            "nc: New Caledonia",
            "ne: Niger",
            "nf: Norfolk Island",
            "ng: Nigeria",
            "ni: Nicaragua",
            "nl: Netherlands",
            "no: Norway",
            "np: Nepal",
            "nr: Nauru",
            "nu: Niue",
            "nz: New Zealand",
            "om: Oman",
            "pa: Panama",
            "pe: Peru",
            "pf: French Polynesia",
            "pg: Papua New Guinea",
            "ph: Philippines",
            "pk: Pakistan",
            "pl: Poland",
            "pm: Saint Pierre and Miquelon",
            "pn: Pitcairn Islands",
            "pr: Puerto Rico",
            "ps: Palestine",
            "pt: Portugal",
            "pw: Palau",
            "py: Paraguay",
            "qa: Qatar",
            "re: Réunion",
            "ro: Romania",
            "rs: Serbia",
            "ru: Russia",
            "rw: Rwanda",
            "sa: Saudi Arabia",
            "sb: Solomon Islands",
            "sc: Seychelles",
            "sd: Sudan",
            "se: Sweden",
            "sg: Singapore",
            "sh: Saint Helena, Ascension and Tristan da Cunha",
            "si: Slovenia",
            "sj: Svalbard and Jan Mayen",
            "sk: Slovakia",
            "sl: Sierra Leone",
            "sm: San Marino",
            "sn: Senegal",
            "so: Somalia",
            "sr: Suriname",
            "ss: South Sudan",
            "st: São Tomé and Príncipe",
            "sv: El Salvador",
            "sx: Sint Maarten",
            "sy: Syria",
            "sz: Eswatini (Swaziland)",
            "tc: Turks and Caicos Islands",
            "td: Chad",
            "tf: French Southern and Antarctic Lands",
            "tg: Togo",
            "th: Thailand",
            "tj: Tajikistan",
            "tk: Tokelau",
            "tl: Timor-Leste",
            "tm: Turkmenistan",
            "tn: Tunisia",
            "to: Tonga",
            "tr: Turkey",
            "tt: Trinidad and Tobago",
            "tv: Tuvalu",
            "tw: Taiwan",
            "tz: Tanzania",
            "ua: Ukraine",
            "ug: Uganda",
            "um: United States Minor Outlying Islands",
            "un: United Nations",
            "us: United States",
            "us-ak: Alaska",
            "us-al: Alabama",
            "us-ar: Arkansas",
            "us-az: Arizona",
            "us-ca: California",
            "us-co: Colorado",
            "us-ct: Connecticut",
            "us-de: Delaware",
            "us-fl: Florida",
            "us-ga: Georgia",
            "us-hi: Hawaii",
            "us-ia: Iowa",
            "us-id: Idaho",
            "us-il: Illinois",
            "us-in: Indiana",
            "us-ks: Kansas",
            "us-ky: Kentucky",
            "us-la: Louisiana",
            "us-ma: Massachusetts",
            "us-md: Maryland",
            "us-me: Maine",
            "us-mi: Michigan",
            "us-mn: Minnesota",
            "us-mo: Missouri",
            "us-ms: Mississippi",
            "us-mt: Montana",
            "us-nc: North Carolina",
            "us-nd: North Dakota",
            "us-ne: Nebraska",
            "us-nh: New Hampshire",
            "us-nj: New Jersey",
            "us-nm: New Mexico",
            "us-nv: Nevada",
            "us-ny: New York",
            "us-oh: Ohio",
            "us-ok: Oklahoma",
            "us-or: Oregon",
            "us-pa: Pennsylvania",
            "us-ri: Rhode Island",
            "us-sc: South Carolina",
            "us-sd: South Dakota",
            "us-tn: Tennessee",
            "us-tx: Texas",
            "us-ut: Utah",
            "us-va: Virginia",
            "us-vt: Vermont",
            "us-wa: Washington",
            "us-wi: Wisconsin",
            "us-wv: West Virginia",
            "us-wy: Wyoming",
            "uy: Uruguay",
            "uz: Uzbekistan",
            "va: Vatican City (Holy See)",
            "vc: Saint Vincent and the Grenadines",
            "ve: Venezuela",
            "vg: British Virgin Islands",
            "vi: United States Virgin Islands",
            "vn: Vietnam",
            "vu: Vanuatu",
            "wf: Wallis and Futuna",
            "ws: Samoa",
            "xk: Kosovo",
            "ye: Yemen",
            "yt: Mayotte",
            "za: South Africa",
            "zm: Zambia",
            "zw: Zimbabwe"});
            this.countriesComboBox.Location = new System.Drawing.Point(10, 104);
            this.countriesComboBox.Name = "countriesComboBox";
            this.countriesComboBox.Size = new System.Drawing.Size(187, 21);
            this.countriesComboBox.TabIndex = 1;
            // 
            // flagPictureBox
            // 
            this.flagPictureBox.Location = new System.Drawing.Point(205, 39);
            this.flagPictureBox.Name = "flagPictureBox";
            this.flagPictureBox.Size = new System.Drawing.Size(320, 220);
            this.flagPictureBox.TabIndex = 2;
            this.flagPictureBox.TabStop = false;
            // 
            // flagPictureLabel
            // 
            this.flagPictureLabel.AutoSize = true;
            this.flagPictureLabel.Font = new System.Drawing.Font("Arial Black", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flagPictureLabel.ForeColor = System.Drawing.Color.SeaGreen;
            this.flagPictureLabel.Location = new System.Drawing.Point(310, 16);
            this.flagPictureLabel.Name = "flagPictureLabel";
            this.flagPictureLabel.Size = new System.Drawing.Size(99, 18);
            this.flagPictureLabel.TabIndex = 3;
            this.flagPictureLabel.Text = "Flag Picture:";
            // 
            // chooseCountryLabel
            // 
            this.chooseCountryLabel.AutoSize = true;
            this.chooseCountryLabel.Location = new System.Drawing.Point(67, 77);
            this.chooseCountryLabel.Name = "chooseCountryLabel";
            this.chooseCountryLabel.Size = new System.Drawing.Size(85, 13);
            this.chooseCountryLabel.TabIndex = 0;
            this.chooseCountryLabel.Text = "Choose Country:";
            // 
            // selectFlagButton
            // 
            this.selectFlagButton.Location = new System.Drawing.Point(70, 131);
            this.selectFlagButton.Name = "selectFlagButton";
            this.selectFlagButton.Size = new System.Drawing.Size(75, 23);
            this.selectFlagButton.TabIndex = 4;
            this.selectFlagButton.Text = "Load";
            this.selectFlagButton.UseVisualStyleBackColor = true;
            this.selectFlagButton.Click += new System.EventHandler(this.selectFlagButton_Click);
            // 
            // saveImageButton
            // 
            this.saveImageButton.Location = new System.Drawing.Point(531, 131);
            this.saveImageButton.Name = "saveImageButton";
            this.saveImageButton.Size = new System.Drawing.Size(89, 49);
            this.saveImageButton.TabIndex = 7;
            this.saveImageButton.Text = "Save Image";
            this.saveImageButton.UseVisualStyleBackColor = true;
            this.saveImageButton.Click += new System.EventHandler(this.saveImageButton_Click);
            // 
            // CountryFlagsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 268);
            this.Controls.Add(this.saveImageButton);
            this.Controls.Add(this.selectFlagButton);
            this.Controls.Add(this.flagPictureLabel);
            this.Controls.Add(this.flagPictureBox);
            this.Controls.Add(this.countriesComboBox);
            this.Controls.Add(this.chooseCountryLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CountryFlagsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Country Flag Viewer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CountryFlagsForm_FormClosing);
            this.Load += new System.EventHandler(this.CountryFlagsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.flagPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox countriesComboBox;
        private System.Windows.Forms.PictureBox flagPictureBox;
        private System.Windows.Forms.Label flagPictureLabel;
        private System.Windows.Forms.Label chooseCountryLabel;
        private System.Windows.Forms.Button selectFlagButton;
        private System.Windows.Forms.Button saveImageButton;
    }
}