﻿using AIO_DemoTools.Properties;
using System;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class DigitalClockForm : Form
    {
        Settings clockSettings = new Settings();

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();


        public DigitalClockForm()
        {
            InitializeComponent();
            TopMost = true;

            ClockTimer.Interval = 500;
            ClockTimer.Tick += UpdateDigitalClock;
            ClockTimer.Start();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DigitalClockForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void DigitalClockForm_Load(object sender, EventArgs e)
        {
            Size = new Size(560, 301);

            if (clockSettings.FormLocation != null)
            {
                Location = clockSettings.FormLocation;
            }
        }

        private void UpdateDigitalClock(object sender, EventArgs e)
        {
            if (clockSettings.SavedTimeZone.Length == 0) // If no time zone is saved, set current time
            {
                clockLabel.Text = DateTime.Now.ToString();
                resetLabel.Visible = false;
            }

            else if (clockSettings.SavedTimeZone.Length > 0) // If time zone is saved in the program's settings, set it
            {
                string savedTimeZoneID = clockSettings.SavedTimeZone;
                var setTimeZoneFromID = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(savedTimeZoneID));

                resetLabel.Visible = true;
                clockLabel.Text = setTimeZoneFromID.ToString();
            }

            else // If time zone is selected from the ListBox, set it
            {
                string timeZoneString = timeZoneListBox.SelectedItem.ToString();
                var setTimeZoneFromListBox = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(timeZoneString));

                resetLabel.Visible = true;
                clockLabel.Text = setTimeZoneFromListBox.ToString();
            }
        }

        private void DigitalClockForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            clockSettings.FormLocation = Location;
            clockSettings.Save();
        }

        private void changeTimeZoneButton_Click(object sender, EventArgs e)
        {
            ClockTimer.Start(); // Reason for starting timer again is to ensure clock stays running. Sometimes it stops when updating its value.
            clockLabel.Text = "Updating Time...";

            try // Reason for catching this exception is if a user clicks 'Change Time Zone' when they haven't selected anything in the ListBox,
            {   // it will return a null value.
                clockSettings.SavedTimeZone = timeZoneListBox.SelectedItem.ToString();
                clockSettings.Save();
            }
            catch (NullReferenceException)
            {

            }

            Size = new Size(560, 301);
        }

        private void resetLabel_Click(object sender, EventArgs e)
        {
            clockLabel.Text = "Updating Time...";
            timeZoneListBox.SelectedIndex = -1;
            ClockTimer.Start();

            clockSettings.SavedTimeZone = "";
            clockSettings.Save();

            Size = new Size(560, 301);
        }

        private void clockLabel_Click(object sender, EventArgs e)
        {
            ReadOnlyCollection<TimeZoneInfo> timeZones = TimeZoneInfo.GetSystemTimeZones();

            if (Width == 560 && Height == 301)
            {
                Size = new Size(560, 568);
            }

            else if (Width == 560 && Height == 568)
            {
                Size = new Size(560, 301);
            }

            foreach (TimeZoneInfo timeZone in timeZones)
            {
                timeZoneListBox.Items.Add(timeZone.Id.ToString());
            }
        }
    }
}
