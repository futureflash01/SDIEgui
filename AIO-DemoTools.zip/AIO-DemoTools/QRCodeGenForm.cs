﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QRCoder;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace AIO_DemoTools
{
    public partial class QRCodeGenForm : Form
    {
        QRCodeGenerator qrGenerator = new QRCodeGenerator();

        public QRCodeGenForm()
        {
            InitializeComponent();
        }

        private void QRCodeGenForm_Load(object sender, EventArgs e)
        {
            this.Size = new Size(224, 275);
            this.CenterToScreen();
            qrCodePitcureBox.SizeMode = PictureBoxSizeMode.Zoom;
            textCheckBox.Checked = true;
            tempLabel.Text = "Enter Text:";
        }

        private void textCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (textCheckBox.Checked == true)
            {
                urlCheckBox.Checked = false;
                wifiCheckBox.Checked = false;
                tempTextBox.Clear();
                passwordTextBox.Clear();

                this.Size = new Size(224, 275);
                this.CenterToScreen();
                tempLabel.Text = "Enter Text:";
            }

            else if (!textCheckBox.Checked && !urlCheckBox.Checked && !wifiCheckBox.Checked)
            {
                textCheckBox.Checked = true;
            }
        }

        private void urlCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (urlCheckBox.Checked == true)
            {
                textCheckBox.Checked = false;
                wifiCheckBox.Checked = false;
                tempTextBox.Clear();
                passwordTextBox.Clear();

                this.Size = new Size(224, 275);
                this.CenterToScreen();
                tempLabel.Text = "Enter URL:";
            }

            else if (!urlCheckBox.Checked && !textCheckBox.Checked && !wifiCheckBox.Checked)
            {
                urlCheckBox.Checked = true;
            }
        }

        private void wifiCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (wifiCheckBox.Checked)
            {
                urlCheckBox.Checked = false;
                textCheckBox.Checked = false;
                tempTextBox.Clear();
                passwordTextBox.Clear();

                passwordLabel.Show();
                passwordTextBox.Show();
                this.Size = new Size(224, 340);
                this.CenterToScreen();
                tempLabel.Text = "WiFi SSID:";

            }

            else if (!wifiCheckBox.Checked && !urlCheckBox.Checked && !textCheckBox.Checked)
            {
                wifiCheckBox.Checked = true;
            }
        }

        private void testButton_Click(object sender, EventArgs e)
        {
            if (tempTextBox.Text.Length == 0)
            {
                MessageBox.Show(
                "One or more inputes are missing. Please make sure to fill out all required text fields",
                "Missing Text Field!",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }

            else
            {

                if (textCheckBox.Checked)
                {
                    passwordLabel.Hide();
                    passwordTextBox.Hide();

                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(tempTextBox.Text, QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(20);
                    qrCodePitcureBox.Image = qrCodeImage;

                    this.Size = new Size(544, 409);
                    this.CenterToScreen();
                }

                else if (urlCheckBox.Checked && (tempTextBox.Text.StartsWith("https://") || tempTextBox.Text.StartsWith("http://")))
                {
                    passwordLabel.Hide();
                    passwordTextBox.Hide();

                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(tempTextBox.Text, QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(20);
                    qrCodePitcureBox.Image = qrCodeImage;

                    this.Size = new Size(544, 409);
                    this.CenterToScreen();
                }

                else if (urlCheckBox.Checked && (!tempTextBox.Text.StartsWith("https://") || !tempTextBox.Text.StartsWith("http://")))
                {
                    MessageBox.Show(
                    "URL has to start with 'http://' or 'https://'.",
                    "Invalid URL!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                }

                else if (wifiCheckBox.Checked && (passwordTextBox.Text.Length >= 1 && tempLabel.Text.Length >= 1))
                {
                    PayloadGenerator.WiFi wifiPayload = new PayloadGenerator.WiFi("", "", PayloadGenerator.WiFi.Authentication.WPA);
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(wifiPayload);
                    Console.WriteLine(wifiPayload.ToString());
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(20);
                    qrCodePitcureBox.Image = qrCodeImage;

                    this.Size = new Size(544, 409);
                    this.CenterToScreen();
                }

                else if (wifiCheckBox.Checked && passwordTextBox.Text.Length == 0)
                {
                    MessageBox.Show(
                    "One or more inputes are missing. Please make sure to fill out all required text fields",
                    "Missing Text Field!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                }
            }
        }
    }
}
