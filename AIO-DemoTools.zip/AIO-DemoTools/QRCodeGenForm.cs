﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using QRCoder;

namespace AIO_DemoTools
{
    public partial class QRCodeGenForm : Form
    {
        private QRCodeGenerator qrGenerator = new QRCodeGenerator();

        public QRCodeGenForm()
        {
            InitializeComponent();
        }

        private void QRCodeGenForm_Load(object sender, EventArgs e)
        {
            InitializeForm();
        }

        private void InitializeForm()
        {
            this.Size = new Size(224, 275);
            this.CenterToScreen();
            generateQRCodeButton.Location = new Point(25, 195);
            qrCodePitcureBox.SizeMode = PictureBoxSizeMode.Zoom;
            textCheckBox.Checked = true;
            UpdateLabelText("Enter Text:");
        }

        private void UpdateLabelText(string text)
        {
            tempLabel.Text = text;
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;

            if (checkBox.Checked)
            {
                textCheckBox.Checked = (checkBox == textCheckBox);
                urlCheckBox.Checked = (checkBox == urlCheckBox);
                wifiCheckBox.Checked = (checkBox == wifiCheckBox);

                tempTextBox.Clear();
                passwordTextBox.Clear();
                passwordLabel.Visible = wifiCheckBox.Checked;
                passwordTextBox.Visible = wifiCheckBox.Checked;

                this.Size = new Size(224, wifiCheckBox.Checked ? 340 : 275);
                generateQRCodeButton.Location = new Point(25, wifiCheckBox.Checked ? 252 : 195);
                this.CenterToScreen();

                if (checkBox == textCheckBox)
                {
                    UpdateLabelText("Enter Text:");
                }

                else if (checkBox == urlCheckBox)
                {
                    UpdateLabelText("Enter URL:");
                }

                else if (checkBox == wifiCheckBox)
                {
                    UpdateLabelText("WiFi SSID:");
                }
            }

            else if (!textCheckBox.Checked && !urlCheckBox.Checked && !wifiCheckBox.Checked)
            {
                checkBox.Checked = true;
            }
        }

        private void generateQRCodeButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tempTextBox.Text))
            {
                MessageBox.Show(
                    "One or more inputs are missing. Please make sure to fill out all required text fields",
                    "Missing Text Field!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
                if (textCheckBox.Checked || (urlCheckBox.Checked && tempTextBox.Text.StartsWith("https://")))
                {
                    GenerateQRCode(tempTextBox.Text);
                }
                else if (urlCheckBox.Checked && !tempTextBox.Text.StartsWith("https://"))
                {
                    MessageBox.Show(
                        "URL has to start with 'https://'.",
                        "Invalid URL!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
                else if (wifiCheckBox.Checked && !string.IsNullOrEmpty(passwordTextBox.Text))
                {
                    GenerateQRCode(new PayloadGenerator.WiFi(tempTextBox.Text, passwordTextBox.Text, PayloadGenerator.WiFi.Authentication.WPA).ToString());
                }
                else if (wifiCheckBox.Checked && string.IsNullOrEmpty(passwordTextBox.Text))
                {
                    MessageBox.Show(
                        "One or more inputs are missing. Please make sure to fill out all required text fields",
                        "Missing Text Field!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void GenerateQRCode(string data)
        {
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(data, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(20);
            qrCodePitcureBox.Image = qrCodeImage;

            this.Size = new Size(544, 409);
            this.CenterToScreen();
        }

        private void QRCodeGenForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            textCheckBox.Checked = true;
            UpdateLabelText("Enter Text:");
            tempTextBox.Clear();
            passwordTextBox.Clear();
        }

        private void tempTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (tempTextBox.Text.Length == 299)
            {
                MessageBox.Show(
                        "Maximum number of characters is 300. Please shorten your text input and try again.",
                        "Character Limit Reached!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                tempTextBox.Text.Remove(tempTextBox.Text.Length - 1, 1);
            }
        }

        private void saveQRButton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog { Filter = @"PNG|*.png" })
            {
                if (saveFileDialog.ShowDialog() != DialogResult.OK)
                {
                    return;
                }

                string fileName = saveFileDialog.FileName;
                qrCodePitcureBox.Image.Save(fileName);
                Thread.Sleep(1000);

                if (File.Exists(fileName))
                {
                    DialogResult dialogResult = MessageBox.Show(
                        $"Image successfully saved to {fileName}. Would you like to view it now?",
                        "Image Saved!",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                    if (dialogResult == DialogResult.Yes)
                    {
                        Process.Start(fileName);
                    }
                }

                else
                {
                    MessageBox.Show(
                        "Image could not be saved. Please try again!",
                        "Image Not Saved!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }
    }
}
