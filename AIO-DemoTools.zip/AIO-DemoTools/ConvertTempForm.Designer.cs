﻿namespace AIO_DemoTools
{
    partial class ConvertTempForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConvertTempForm));
            this.FLabel = new System.Windows.Forms.Label();
            this.CLabel = new System.Windows.Forms.Label();
            this.FTextbox = new System.Windows.Forms.TextBox();
            this.CTextbox = new System.Windows.Forms.TextBox();
            this.switchButton = new System.Windows.Forms.Button();
            this.convertButton = new System.Windows.Forms.Button();
            this.clearLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // FLabel
            // 
            this.FLabel.AutoSize = true;
            this.FLabel.Location = new System.Drawing.Point(41, 38);
            this.FLabel.Name = "FLabel";
            this.FLabel.Size = new System.Drawing.Size(57, 13);
            this.FLabel.TabIndex = 0;
            this.FLabel.Text = "Fahrenheit";
            // 
            // CLabel
            // 
            this.CLabel.AutoSize = true;
            this.CLabel.Location = new System.Drawing.Point(245, 39);
            this.CLabel.Name = "CLabel";
            this.CLabel.Size = new System.Drawing.Size(40, 13);
            this.CLabel.TabIndex = 1;
            this.CLabel.Text = "Celsius";
            // 
            // FTextbox
            // 
            this.FTextbox.Location = new System.Drawing.Point(22, 55);
            this.FTextbox.Name = "FTextbox";
            this.FTextbox.Size = new System.Drawing.Size(100, 20);
            this.FTextbox.TabIndex = 2;
            this.FTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FTextbox_KeyPress);
            // 
            // CTextbox
            // 
            this.CTextbox.Location = new System.Drawing.Point(215, 55);
            this.CTextbox.Name = "CTextbox";
            this.CTextbox.Size = new System.Drawing.Size(100, 20);
            this.CTextbox.TabIndex = 3;
            this.CTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CTextbox_KeyPress);
            // 
            // switchButton
            // 
            this.switchButton.Image = ((System.Drawing.Image)(resources.GetObject("switchButton.Image")));
            this.switchButton.Location = new System.Drawing.Point(148, 49);
            this.switchButton.Name = "switchButton";
            this.switchButton.Size = new System.Drawing.Size(36, 33);
            this.switchButton.TabIndex = 4;
            this.switchButton.UseVisualStyleBackColor = true;
            this.switchButton.Click += new System.EventHandler(this.switchButton_Click);
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(129, 98);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(75, 32);
            this.convertButton.TabIndex = 5;
            this.convertButton.Text = "Convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // clearLabel
            // 
            this.clearLabel.AutoSize = true;
            this.clearLabel.BackColor = System.Drawing.SystemColors.Control;
            this.clearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearLabel.ForeColor = System.Drawing.Color.Red;
            this.clearLabel.Location = new System.Drawing.Point(212, 108);
            this.clearLabel.Name = "clearLabel";
            this.clearLabel.Size = new System.Drawing.Size(31, 13);
            this.clearLabel.TabIndex = 6;
            this.clearLabel.Text = "Clear";
            this.clearLabel.Click += new System.EventHandler(this.clearLabel_Click);
            // 
            // ConvertTempForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 150);
            this.Controls.Add(this.clearLabel);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.switchButton);
            this.Controls.Add(this.CTextbox);
            this.Controls.Add(this.FTextbox);
            this.Controls.Add(this.CLabel);
            this.Controls.Add(this.FLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ConvertTempForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Temperature Converter";
            this.Load += new System.EventHandler(this.ConvertTempForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FLabel;
        private System.Windows.Forms.Label CLabel;
        private System.Windows.Forms.TextBox FTextbox;
        private System.Windows.Forms.TextBox CTextbox;
        private System.Windows.Forms.Button switchButton;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Label clearLabel;
    }
}