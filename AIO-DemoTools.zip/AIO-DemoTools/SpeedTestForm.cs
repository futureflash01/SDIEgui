﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;

namespace AIO_DemoTools
{
    public partial class SpeedTestForm : Form
    {
        
        public SpeedTestForm()
        {
            InitializeComponent();
        }

        Stopwatch watch = new Stopwatch();

        private void speedTestButton_Click(object sender, EventArgs e)
        {
            watch.Start();
            WebClient web = new WebClient();
            byte[] bytes = web.DownloadData("https://ash-speed.hetzner.com/100MB.bin");
            watch.Stop();
            double sec = watch.Elapsed.TotalSeconds;
            double speed = bytes.Count() / sec;
            double speedInMB = speed / 125000;

            Console.WriteLine(speedInMB + " MBps");
            Console.Read();
        }
    }
}
