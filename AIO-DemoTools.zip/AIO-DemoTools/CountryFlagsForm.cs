﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using File = System.IO.File;

namespace AIO_DemoTools
{
    public partial class CountryFlagsForm : Form
    {
        private const string FlagsApiUrl = "https://flagcdn.com/w1280/";

        public CountryFlagsForm()
        {
            InitializeComponent();
        }

        private void CountryFlagsForm_Load(object sender, EventArgs e)
        {
            flagPictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            countriesComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            saveImageButton.Enabled = false;

            this.Size = new Size(221, 307);
            this.CenterToScreen();
        }

        private void ClearForm()
        {
            countriesComboBox.SelectedIndex = -1;
            saveImageButton.Enabled = false;
            flagPictureBox.Image = null;
        }

        private void selectFlagButton_Click(object sender, EventArgs e)
        {
            if (countriesComboBox.Text.Length == 0)
            {
                MessageBox.Show(
                    "Please choose a country before loading",
                    "Empty Selection",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            string countryCode = countriesComboBox.Text.Split(':')[0];

            try
            {
                string imageUrl = $"{FlagsApiUrl}{countryCode}.png";
                flagPictureBox.Load(imageUrl);
                saveImageButton.Enabled = true;
                
                if (Width == 221 && Height == 307)
                {
                    Size = new Size(646, 307);
                    CenterToScreen();
                }
            }
            catch (WebException)
            {
                MessageBox.Show(
                    $"Could not find the country: '{countriesComboBox.Text}'",
                    "Invalid Selection",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }

        private void saveImageButton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog { Filter = @"PNG|*.png" })
            {
                if (saveFileDialog.ShowDialog() != DialogResult.OK)
                    return;

                string fileName = saveFileDialog.FileName;
                flagPictureBox.Image.Save(fileName);
                Thread.Sleep(1000);

                if (File.Exists(fileName))
                {
                    DialogResult dialogResult = MessageBox.Show(
                        $"Image successfully saved to {fileName}. Would you like to view it now?",
                        "Image Saved!",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                    if (dialogResult == DialogResult.Yes)
                    {
                        Process.Start(fileName);
                    }
                }
                else
                {
                    MessageBox.Show(
                        "Image could not be saved. Please try again!",
                        "Image Not Saved!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                }
            }
        }

        private void CountryFlagsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ClearForm();
        }
    }
}