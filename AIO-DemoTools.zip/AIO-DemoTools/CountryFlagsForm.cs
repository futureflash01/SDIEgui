﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using File = System.IO.File;

namespace AIO_DemoTools
{

    public partial class CountryFlagsForm : Form
    {

        // Credits to FlagsCDN for providing the pictured of the flags: https://flagpedia.net/download/api
        public CountryFlagsForm()
        {
            InitializeComponent();
        }

        private void ClearForm()
        {
            countriesComboBox.SelectedIndex = -1;
            saveImageButton.Enabled = false;
            flagPictureBox.Image = null;
        }

        private void CountryFlagsForm_Load(object sender, EventArgs e)
        {
            flagPictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            countriesComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            saveImageButton.Enabled = false;

            this.Size = new Size(221, 307);
            this.CenterToScreen();
        }
        
        private void selectFlagButton_Click(object sender, EventArgs e)
        {
            string countryCode = countriesComboBox.Text.Split(':').First();

            try
            {
                if (countriesComboBox.Text.Length == 0)
                {
                    MessageBox.Show(
                    "Please choose a country before loading",
                    "Empty Selection",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                }
                else
                {
                    flagPictureBox.Load("https://flagcdn.com/w1280/" + countryCode + ".png");
                    saveImageButton.Enabled = true;

                    this.Size = new Size(646, 307);
                    this.CenterToScreen();
                }
            }
            catch (WebException)
            {
                MessageBox.Show(
                $"Coud not find the country: '{countriesComboBox.Text}'",
                "Invalid Selection",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            }
        }

        private void saveImageButton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog() { Filter = @"PNG|*.png" })
            {
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    flagPictureBox.Image.Save(saveFileDialog.FileName);
                    Thread.Sleep(1000);

                    if (File.Exists(saveFileDialog.FileName))
                    {
                        DialogResult dialogResult = MessageBox.Show(
                        $"Image successfully saved to {saveFileDialog.FileName}. Would you like to view it now?",
                        "Image Saved!",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information);

                        if (dialogResult == DialogResult.Yes)
                        {
                            Process.Start(saveFileDialog.FileName);
                        }
                    }

                    else
                    {
                        MessageBox.Show(
                        "Image could not be saved. Please try again!",
                        "Image Not Saved!",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void CountryFlagsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ClearForm();
        }
    }
}
