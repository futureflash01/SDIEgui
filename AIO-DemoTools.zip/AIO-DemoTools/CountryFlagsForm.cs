﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace AIO_DemoTools
{
    
    public partial class CountryFlagsForm : Form
    {
        public CountryFlagsForm()
        {
            InitializeComponent();
        }

        private void CountryFlagsForm_Load(object sender, EventArgs e)
        {
            flagPictureBox.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        private void selectFlagButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (countriesComboBox.Text.Length == 0)
                {
                    MessageBox.Show("Please choose a country before loading", "Empty Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    flagPictureBox.Load("https://flagcdn.com/w320/" + countriesComboBox.Text + ".png");
                }
            }
            catch (WebException)
            {
                MessageBox.Show($"Coud not find the country: '{countriesComboBox.Text}'", "Invalid Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
