﻿namespace AIO_DemoTools
{
    partial class AIOToolsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AIOToolsForm));
            this.convertTempButton = new System.Windows.Forms.Button();
            this.countryFlagsButton = new System.Windows.Forms.Button();
            this.versionLabel = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateQRButton = new System.Windows.Forms.Button();
            this.diceRollButton = new System.Windows.Forms.Button();
            this.digitalClockButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // convertTempButton
            // 
            this.convertTempButton.BackColor = System.Drawing.Color.PaleTurquoise;
            this.convertTempButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.convertTempButton.Font = new System.Drawing.Font("Franklin Gothic Heavy", 10.5F);
            this.convertTempButton.ForeColor = System.Drawing.Color.Brown;
            this.convertTempButton.Location = new System.Drawing.Point(12, 42);
            this.convertTempButton.Name = "convertTempButton";
            this.convertTempButton.Size = new System.Drawing.Size(109, 76);
            this.convertTempButton.TabIndex = 0;
            this.convertTempButton.Text = "Convert Temperature";
            this.convertTempButton.UseVisualStyleBackColor = false;
            this.convertTempButton.Click += new System.EventHandler(this.convertTempButton_Click);
            // 
            // countryFlagsButton
            // 
            this.countryFlagsButton.BackColor = System.Drawing.Color.Thistle;
            this.countryFlagsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.countryFlagsButton.Font = new System.Drawing.Font("Franklin Gothic Heavy", 11F);
            this.countryFlagsButton.ForeColor = System.Drawing.Color.Black;
            this.countryFlagsButton.Location = new System.Drawing.Point(141, 42);
            this.countryFlagsButton.Name = "countryFlagsButton";
            this.countryFlagsButton.Size = new System.Drawing.Size(109, 76);
            this.countryFlagsButton.TabIndex = 1;
            this.countryFlagsButton.Text = "Country\r\nFlags";
            this.countryFlagsButton.UseVisualStyleBackColor = false;
            this.countryFlagsButton.Click += new System.EventHandler(this.countryFlagsButton_Click);
            // 
            // versionLabel
            // 
            this.versionLabel.AutoSize = true;
            this.versionLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.versionLabel.Location = new System.Drawing.Point(229, 297);
            this.versionLabel.Name = "versionLabel";
            this.versionLabel.Size = new System.Drawing.Size(28, 13);
            this.versionLabel.TabIndex = 2;
            this.versionLabel.Text = "v1.0";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(263, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.BackColor = System.Drawing.Color.MistyRose;
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // generateQRButton
            // 
            this.generateQRButton.BackColor = System.Drawing.Color.LightGreen;
            this.generateQRButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.generateQRButton.Font = new System.Drawing.Font("Franklin Gothic Heavy", 11F);
            this.generateQRButton.ForeColor = System.Drawing.Color.MidnightBlue;
            this.generateQRButton.Location = new System.Drawing.Point(12, 144);
            this.generateQRButton.Name = "generateQRButton";
            this.generateQRButton.Size = new System.Drawing.Size(109, 76);
            this.generateQRButton.TabIndex = 4;
            this.generateQRButton.Text = "QR Code\r\nGenerator";
            this.generateQRButton.UseVisualStyleBackColor = false;
            this.generateQRButton.Click += new System.EventHandler(this.generateQRButton_Click);
            // 
            // diceRollButton
            // 
            this.diceRollButton.BackColor = System.Drawing.Color.IndianRed;
            this.diceRollButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.diceRollButton.Font = new System.Drawing.Font("Franklin Gothic Heavy", 11F);
            this.diceRollButton.Location = new System.Drawing.Point(141, 144);
            this.diceRollButton.Name = "diceRollButton";
            this.diceRollButton.Size = new System.Drawing.Size(109, 76);
            this.diceRollButton.TabIndex = 5;
            this.diceRollButton.Text = "Roll A Dice";
            this.diceRollButton.UseVisualStyleBackColor = false;
            this.diceRollButton.Click += new System.EventHandler(this.diceRollButton_Click);
            // 
            // digitalClockButton
            // 
            this.digitalClockButton.BackColor = System.Drawing.Color.Wheat;
            this.digitalClockButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.digitalClockButton.Font = new System.Drawing.Font("Franklin Gothic Heavy", 11F);
            this.digitalClockButton.Location = new System.Drawing.Point(78, 230);
            this.digitalClockButton.Name = "digitalClockButton";
            this.digitalClockButton.Size = new System.Drawing.Size(109, 76);
            this.digitalClockButton.TabIndex = 6;
            this.digitalClockButton.Text = "Digital\r\nClock";
            this.digitalClockButton.UseVisualStyleBackColor = false;
            this.digitalClockButton.Click += new System.EventHandler(this.digitalClockButton_Click);
            // 
            // AIOToolsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 316);
            this.Controls.Add(this.digitalClockButton);
            this.Controls.Add(this.diceRollButton);
            this.Controls.Add(this.generateQRButton);
            this.Controls.Add(this.versionLabel);
            this.Controls.Add(this.countryFlagsButton);
            this.Controls.Add(this.convertTempButton);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "AIOToolsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "All in One Tools";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button convertTempButton;
        private System.Windows.Forms.Button countryFlagsButton;
        private System.Windows.Forms.Label versionLabel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button generateQRButton;
        private System.Windows.Forms.Button diceRollButton;
        private System.Windows.Forms.Button digitalClockButton;
    }
}

