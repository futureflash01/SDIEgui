﻿namespace AIO_DemoTools
{
    partial class QRCodeGenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QRCodeGenForm));
            this.qrCodePitcureBox = new System.Windows.Forms.PictureBox();
            this.saveQRButton = new System.Windows.Forms.Button();
            this.qrCodeIndicatorLabel = new System.Windows.Forms.Label();
            this.chooseQRLabel = new System.Windows.Forms.Label();
            this.tempTextBox = new System.Windows.Forms.TextBox();
            this.tempLabel = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.passwordTextBox = new System.Windows.Forms.TextBox();
            this.textCheckBox = new System.Windows.Forms.CheckBox();
            this.wifiCheckBox = new System.Windows.Forms.CheckBox();
            this.urlCheckBox = new System.Windows.Forms.CheckBox();
            this.generateQRCodeButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.qrCodePitcureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // qrCodePitcureBox
            // 
            this.qrCodePitcureBox.Location = new System.Drawing.Point(214, 32);
            this.qrCodePitcureBox.Name = "qrCodePitcureBox";
            this.qrCodePitcureBox.Size = new System.Drawing.Size(293, 281);
            this.qrCodePitcureBox.TabIndex = 0;
            this.qrCodePitcureBox.TabStop = false;
            // 
            // saveQRButton
            // 
            this.saveQRButton.Location = new System.Drawing.Point(327, 321);
            this.saveQRButton.Name = "saveQRButton";
            this.saveQRButton.Size = new System.Drawing.Size(78, 37);
            this.saveQRButton.TabIndex = 1;
            this.saveQRButton.Text = "Save";
            this.saveQRButton.UseVisualStyleBackColor = true;
            this.saveQRButton.Click += new System.EventHandler(this.saveQRButton_Click);
            // 
            // qrCodeIndicatorLabel
            // 
            this.qrCodeIndicatorLabel.AutoSize = true;
            this.qrCodeIndicatorLabel.Font = new System.Drawing.Font("Arial Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qrCodeIndicatorLabel.Location = new System.Drawing.Point(323, 5);
            this.qrCodeIndicatorLabel.Name = "qrCodeIndicatorLabel";
            this.qrCodeIndicatorLabel.Size = new System.Drawing.Size(87, 22);
            this.qrCodeIndicatorLabel.TabIndex = 2;
            this.qrCodeIndicatorLabel.Text = "QR Code:";
            // 
            // chooseQRLabel
            // 
            this.chooseQRLabel.AutoSize = true;
            this.chooseQRLabel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chooseQRLabel.ForeColor = System.Drawing.Color.ForestGreen;
            this.chooseQRLabel.Location = new System.Drawing.Point(21, 52);
            this.chooseQRLabel.Name = "chooseQRLabel";
            this.chooseQRLabel.Size = new System.Drawing.Size(132, 15);
            this.chooseQRLabel.TabIndex = 4;
            this.chooseQRLabel.Text = "Choose QR Code type:";
            // 
            // tempTextBox
            // 
            this.tempTextBox.Location = new System.Drawing.Point(22, 165);
            this.tempTextBox.MaxLength = 300;
            this.tempTextBox.Name = "tempTextBox";
            this.tempTextBox.Size = new System.Drawing.Size(162, 20);
            this.tempTextBox.TabIndex = 5;
            this.tempTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tempTextBox_KeyPress);
            // 
            // tempLabel
            // 
            this.tempLabel.AutoSize = true;
            this.tempLabel.Location = new System.Drawing.Point(22, 148);
            this.tempLabel.Name = "tempLabel";
            this.tempLabel.Size = new System.Drawing.Size(59, 13);
            this.tempLabel.TabIndex = 6;
            this.tempLabel.Text = "WiFi SSID:";
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Location = new System.Drawing.Point(25, 197);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(80, 13);
            this.passwordLabel.TabIndex = 7;
            this.passwordLabel.Text = "WiFi Password:";
            // 
            // passwordTextBox
            // 
            this.passwordTextBox.Location = new System.Drawing.Point(25, 215);
            this.passwordTextBox.Name = "passwordTextBox";
            this.passwordTextBox.Size = new System.Drawing.Size(162, 20);
            this.passwordTextBox.TabIndex = 5;
            // 
            // textCheckBox
            // 
            this.textCheckBox.AutoSize = true;
            this.textCheckBox.Location = new System.Drawing.Point(23, 74);
            this.textCheckBox.Name = "textCheckBox";
            this.textCheckBox.Size = new System.Drawing.Size(47, 17);
            this.textCheckBox.TabIndex = 8;
            this.textCheckBox.Text = "Text";
            this.textCheckBox.UseVisualStyleBackColor = true;
            this.textCheckBox.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // wifiCheckBox
            // 
            this.wifiCheckBox.AutoSize = true;
            this.wifiCheckBox.Location = new System.Drawing.Point(22, 119);
            this.wifiCheckBox.Name = "wifiCheckBox";
            this.wifiCheckBox.Size = new System.Drawing.Size(104, 17);
            this.wifiCheckBox.TabIndex = 8;
            this.wifiCheckBox.Text = "WiFi Connection";
            this.wifiCheckBox.UseVisualStyleBackColor = true;
            this.wifiCheckBox.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // urlCheckBox
            // 
            this.urlCheckBox.AutoSize = true;
            this.urlCheckBox.Location = new System.Drawing.Point(22, 96);
            this.urlCheckBox.Name = "urlCheckBox";
            this.urlCheckBox.Size = new System.Drawing.Size(48, 17);
            this.urlCheckBox.TabIndex = 8;
            this.urlCheckBox.Text = "URL";
            this.urlCheckBox.UseVisualStyleBackColor = true;
            this.urlCheckBox.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // generateQRCodeButton
            // 
            this.generateQRCodeButton.Location = new System.Drawing.Point(25, 252);
            this.generateQRCodeButton.Name = "generateQRCodeButton";
            this.generateQRCodeButton.Size = new System.Drawing.Size(159, 29);
            this.generateQRCodeButton.TabIndex = 9;
            this.generateQRCodeButton.Text = "Generate QR Code";
            this.generateQRCodeButton.UseVisualStyleBackColor = true;
            this.generateQRCodeButton.Click += new System.EventHandler(this.generateQRCodeButton_Click);
            // 
            // QRCodeGenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 370);
            this.Controls.Add(this.generateQRCodeButton);
            this.Controls.Add(this.urlCheckBox);
            this.Controls.Add(this.wifiCheckBox);
            this.Controls.Add(this.textCheckBox);
            this.Controls.Add(this.passwordLabel);
            this.Controls.Add(this.tempLabel);
            this.Controls.Add(this.passwordTextBox);
            this.Controls.Add(this.tempTextBox);
            this.Controls.Add(this.chooseQRLabel);
            this.Controls.Add(this.qrCodeIndicatorLabel);
            this.Controls.Add(this.saveQRButton);
            this.Controls.Add(this.qrCodePitcureBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "QRCodeGenForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QR Code Generator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QRCodeGenForm_FormClosing);
            this.Load += new System.EventHandler(this.QRCodeGenForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.qrCodePitcureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox qrCodePitcureBox;
        private System.Windows.Forms.Button saveQRButton;
        private System.Windows.Forms.Label qrCodeIndicatorLabel;
        private System.Windows.Forms.Label chooseQRLabel;
        private System.Windows.Forms.TextBox tempTextBox;
        private System.Windows.Forms.Label tempLabel;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.TextBox passwordTextBox;
        private System.Windows.Forms.CheckBox textCheckBox;
        private System.Windows.Forms.CheckBox wifiCheckBox;
        private System.Windows.Forms.CheckBox urlCheckBox;
        private System.Windows.Forms.Button generateQRCodeButton;
    }
}