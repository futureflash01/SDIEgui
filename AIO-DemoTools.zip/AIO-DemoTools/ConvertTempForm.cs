﻿using System;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class ConvertTempForm : Form
    {

        public ConvertTempForm()
        {
            InitializeComponent();
        }

        private void ClearForm()
        {
            FTextbox.Clear();
            CTextbox.Clear();
        }

        private void ConvertTempForm_Load(object sender, EventArgs e)
        {
            CTextbox.Enabled = false;
        }

        private void switchButton_Click(object sender, EventArgs e)
        {
            if (FTextbox.Enabled)
            {
                FTextbox.Enabled = false;
                CTextbox.Enabled = true;
            }

            else if (CTextbox.Enabled)
            {
                CTextbox.Enabled = false;
                FTextbox.Enabled = true;
            }
        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if (((e.KeyChar == '-') || (e.KeyChar == '.')) && ((sender as TextBox).Text.IndexOf('-') > -1) && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void resetLabel_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (CTextbox.Enabled && !FTextbox.Enabled)
                {
                    double cInt = double.Parse(CTextbox.Text);
                    decimal result1 = Convert.ToDecimal((cInt * 9 / 5) + 32);
                    string finalResult1 = Math.Round(result1, 2).ToString();
                    FTextbox.Text = finalResult1;
                }
                else if (FTextbox.Enabled && !CTextbox.Enabled)
                {
                    double fInt = double.Parse(FTextbox.Text);
                    decimal result2 = Convert.ToDecimal((fInt - 32) * 5 / 9);
                    string finalResult2 = Math.Round(result2, 2).ToString();
                    CTextbox.Text = finalResult2;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show(
                    "Please input a real number and try again",
                    "Invalid Input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }
    }
}