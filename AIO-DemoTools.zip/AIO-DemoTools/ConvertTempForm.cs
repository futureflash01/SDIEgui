﻿using System;
using System.Windows.Forms;

namespace AIO_DemoTools
{
    public partial class ConvertTempForm : Form
    {
        public bool CtoF;
        public bool FtoC;

        public ConvertTempForm()
        {
            InitializeComponent();
        }

        private void ClearForm()
        {
            FTextbox.Clear();
            CTextbox.Clear();
        }

        private void ConvertTempForm_Load(object sender, EventArgs e)
        {
            CTextbox.Enabled = false;
            FtoC = true;
        }

        private void switchButton_Click(object sender, EventArgs e)
        {
            FtoC = !CTextbox.Enabled;
            CtoF = CTextbox.Enabled;

            CTextbox.Enabled = FtoC;
            FTextbox.Enabled = CtoF;
        }

        private void TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-') && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if (((e.KeyChar == '-') || (e.KeyChar == '.')) && ((sender as TextBox).Text.IndexOf('-') > -1) && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void resetLabel_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (CtoF)
                {
                    double cInt = double.Parse(CTextbox.Text);
                    FTextbox.Text = ((cInt * 9 / 5) + 32).ToString();
                }
                else if (FtoC)
                {
                    double fInt = double.Parse(FTextbox.Text);
                    CTextbox.Text = ((fInt - 32) * 5 / 9).ToString();
                }
            }
            catch (FormatException)
            {
                MessageBox.Show(
                    "Please input a real number and try again",
                    "Invalid Input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }
        }
    }
}