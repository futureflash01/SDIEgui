﻿namespace AIO_DemoTools
{
    partial class SpeedTestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SpeedTestForm));
            this.speedTestButton = new System.Windows.Forms.Button();
            this.speedProgressBar = new System.Windows.Forms.ProgressBar();
            this.progressLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // speedTestButton
            // 
            this.speedTestButton.Location = new System.Drawing.Point(141, 121);
            this.speedTestButton.Name = "speedTestButton";
            this.speedTestButton.Size = new System.Drawing.Size(75, 23);
            this.speedTestButton.TabIndex = 0;
            this.speedTestButton.Text = "button1";
            this.speedTestButton.UseVisualStyleBackColor = true;
            this.speedTestButton.Click += new System.EventHandler(this.speedTestButton_Click);
            // 
            // speedProgressBar
            // 
            this.speedProgressBar.Location = new System.Drawing.Point(12, 180);
            this.speedProgressBar.Name = "speedProgressBar";
            this.speedProgressBar.Size = new System.Drawing.Size(445, 23);
            this.speedProgressBar.TabIndex = 1;
            // 
            // progressLabel
            // 
            this.progressLabel.AutoSize = true;
            this.progressLabel.Location = new System.Drawing.Point(119, 72);
            this.progressLabel.Name = "progressLabel";
            this.progressLabel.Size = new System.Drawing.Size(35, 13);
            this.progressLabel.TabIndex = 2;
            this.progressLabel.Text = "label1";
            // 
            // SpeedTestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(469, 434);
            this.Controls.Add(this.progressLabel);
            this.Controls.Add(this.speedProgressBar);
            this.Controls.Add(this.speedTestButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SpeedTestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SpeedTestForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button speedTestButton;
        private System.Windows.Forms.ProgressBar speedProgressBar;
        private System.Windows.Forms.Label progressLabel;
    }
}