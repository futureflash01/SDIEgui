﻿namespace AIO_DemoTools
{
    partial class DigitalClockForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DigitalClockForm));
            this.closeButton = new System.Windows.Forms.Button();
            this.ClockTimer = new System.Windows.Forms.Timer(this.components);
            this.clockLabel = new System.Windows.Forms.Label();
            this.timeZoneListBox = new System.Windows.Forms.ListBox();
            this.changeTimeZoneButton = new System.Windows.Forms.Button();
            this.resetLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // closeButton
            // 
            this.closeButton.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.closeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeButton.Font = new System.Drawing.Font("Arial Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeButton.Location = new System.Drawing.Point(521, 12);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(27, 26);
            this.closeButton.TabIndex = 0;
            this.closeButton.Text = "X";
            this.closeButton.UseVisualStyleBackColor = false;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // clockLabel
            // 
            this.clockLabel.Font = new System.Drawing.Font("Imprint MT Shadow", 65F);
            this.clockLabel.ForeColor = System.Drawing.SystemColors.Control;
            this.clockLabel.Location = new System.Drawing.Point(12, 41);
            this.clockLabel.Name = "clockLabel";
            this.clockLabel.Size = new System.Drawing.Size(536, 243);
            this.clockLabel.TabIndex = 1;
            this.clockLabel.Text = "Updating Time...";
            this.clockLabel.Click += new System.EventHandler(this.clockLabel_Click);
            // 
            // timeZoneListBox
            // 
            this.timeZoneListBox.FormattingEnabled = true;
            this.timeZoneListBox.Location = new System.Drawing.Point(31, 303);
            this.timeZoneListBox.Name = "timeZoneListBox";
            this.timeZoneListBox.Size = new System.Drawing.Size(496, 212);
            this.timeZoneListBox.TabIndex = 3;
            // 
            // changeTimeZoneButton
            // 
            this.changeTimeZoneButton.Location = new System.Drawing.Point(211, 524);
            this.changeTimeZoneButton.Name = "changeTimeZoneButton";
            this.changeTimeZoneButton.Size = new System.Drawing.Size(115, 33);
            this.changeTimeZoneButton.TabIndex = 2;
            this.changeTimeZoneButton.Text = "Change Time Zone";
            this.changeTimeZoneButton.UseVisualStyleBackColor = true;
            this.changeTimeZoneButton.Click += new System.EventHandler(this.changeTimeZoneButton_Click);
            // 
            // resetLabel
            // 
            this.resetLabel.AutoSize = true;
            this.resetLabel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.resetLabel.Font = new System.Drawing.Font("Arial", 8.5F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.resetLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.resetLabel.Location = new System.Drawing.Point(332, 533);
            this.resetLabel.Name = "resetLabel";
            this.resetLabel.Size = new System.Drawing.Size(40, 15);
            this.resetLabel.TabIndex = 4;
            this.resetLabel.Text = "Reset";
            this.resetLabel.Click += new System.EventHandler(this.resetLabel_Click);
            // 
            // DigitalClockForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(560, 568);
            this.Controls.Add(this.resetLabel);
            this.Controls.Add(this.timeZoneListBox);
            this.Controls.Add(this.changeTimeZoneButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.clockLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "DigitalClockForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Digital Clock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DigitalClockForm_FormClosing);
            this.Load += new System.EventHandler(this.DigitalClockForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DigitalClockForm_MouseDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Timer ClockTimer;
        private System.Windows.Forms.Label clockLabel;
        private System.Windows.Forms.ListBox timeZoneListBox;
        private System.Windows.Forms.Button changeTimeZoneButton;
        private System.Windows.Forms.Label resetLabel;
    }
}